![banner](https://cdn.discordapp.com/attachments/907501464736382997/916227596260356126/arceus.jpg)
![Powered by Nextcord](https://custom-icon-badges.herokuapp.com/badge/-Powered%20by%20Nextcord-0d1620?logo=nextcord)
<p align="center">
    <a href="https://github.com/w7cep/Greninjas-Grotto/issues"><img src="https://img.shields.io/github/issues/redcokedevelopment/teapot.py.svg?color=purple&style=flat-square" alt="GitHub Issues"></a>
    <a href="https://github.com/w7cep/Greninjas-Grotto/pulls"><img src="https://img.shields.io/github/issues-pr/redcokedevelopment/teapot.py.svg?color=purple&style=flat-square" alt="GitHub Pull Requests"></a>
    <a href="https://github.com/w7cep/Greninjas-Grotto/stargazers"><img src="https://img.shields.io/github/stars/redcokedevelopment/teapot.py.svg?style=flat-square" alt="GitHub Stars"></a>
    <br><br>

</p>

<h2 align="center">
    This project is currently in development!<br>
</h2>
<h4 align="center">
    If you would like to be notified when we commit, please watch this repository and join our Discord server.
</h4>


## 👋 About

Arceus is a discord bot for member moderation and server management.

If you want to try it out by yourself, feel free to invite it to your Discord server by clicking [Here](https://discord.com/api/oauth2/authorize?client_id=909159653315842060&permissions=396713389174&scope=bot)!

## ⌨ Planned Features
- Music Player
- Economy
- More Fun Commands


## 📖 Wiki

Our wiki is currently work in progress, please check back later!

## 🤝 Contributing
Contributions, feedback, and bug reports are welcome! Feel free to check out our [issues page](https://github.com/w7cep/Greninjas-Grotto/issues) to find out what you could do!

Before contributing, we recommend you say hi over in our [Discord server](https://discord.gg/dm7gSAT68d)! We can provide support with any issues you may have 🙂

A big thanks to all those who contribute to the project ❤

## 💼 Project Owners 
There are two owners for this project. They all contribute massively to the running of this project. Links to their GitHub profiles can be found below:

- [W7CEP](https://github.com/W7CEP) (W7CEP#0001)

## 💖 Credits
The projects listed in below have provided inspiration, and we thought we'd mention them:

- Teapot Devs(README.md): https://github.com/RedCokeDevelopment/Teapot.py.git